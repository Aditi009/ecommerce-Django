from django import template
register=template.Library()

@register.filter(name="is_in_cart")
def is_in_cart(product,cart):
    keys=cart.keys();
    for key in keys:
        if(int(key)==product.id):
            return True
    return False\

@register.filter(name="card_quantity")
def card_quantity(product,cart):
    keys=cart.keys();
    for key in keys:
        if(int(key)==product.id):
            return cart[key]
    return False
@register.filter(name="total_price")
def total_price(product,cart):
    return product.price * card_quantity(product,cart)


@register.filter(name="total_price_all_product")
def total_price_all_product(products,cart):
    sum=0
    for i in products:
        sum=sum+total_price(i,cart)
    return sum




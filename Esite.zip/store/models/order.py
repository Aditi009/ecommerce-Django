from django.db import models
from .customer import Customer
from .product import Product
import datetime

class Order(models.Model):
    product=models.ForeignKey(Product,on_delete=models.CASCADE)
    customer=models.ForeignKey(Customer,on_delete=models.CASCADE)
    quantity=models.IntegerField(default=1)
    date = models.DateField(default=datetime.datetime.today)
    price=models.IntegerField()
    address=models.CharField(max_length=50,blank=True,default='')
    phone=models.CharField(max_length=50,default='',blank=True)
    status=models.BooleanField(default=False)

    def placeOrder(self):
        self.save()

    @staticmethod
    def get_order_by_customer(id):
        return Order\
            .objects\
            .filter(customer=id)\
            .order_by('-date')
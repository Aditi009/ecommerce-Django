from django.db import models
class Customer(models.Model):
    first_name=models.CharField(max_length=25)
    last_name=models.CharField(max_length=25)
    email=models.EmailField()
    phone=models.CharField(max_length=15)
    password=models.CharField(max_length=25)

    def register(self):
        self.save();

    @staticmethod
    def get_user_by_email(email):
        try:
            return Customer.objects.get(email=email)
        except:
            return False

from django.shortcuts import render, redirect
from store.models.product import Product
from django.contrib.auth.hashers import make_password, check_password
from store.models.category import Category

from django.views import View
from django.http import HttpResponse


# Create your views here
class Index(View):
    def get(self,request):
        product = None;
        cart=request.session.get('cart')
        if not cart:
            request.session.cart={}

        categoryId = request.GET.get('category')
        if categoryId:
            product = Product.get_all_product_by_categoryId(categoryId)
        else:
            product = Product.get_all_product();

        category = Category.collect_all_category();
        return render(request, 'index.html', {'product': product, 'category': category})
    def post(self,request):
        product_id=request.POST.get('product')
        cart=request.session.get('cart')
        remove=request.POST.get('remove')
        print(remove)
        if(cart):
            count=cart.get(product_id)
            if count:
                if remove:
                    if count<=1:
                        cart.pop(product_id)
                    else:
                        cart[product_id] =count-1
                else:
                    cart[product_id]=count+1
            else:
                cart[product_id] = 1



        else:
            cart={}
            cart[product_id]=1
        request.session['cart']=cart
        print(request.session.get('cart'))
        return redirect('homepage')


# class based

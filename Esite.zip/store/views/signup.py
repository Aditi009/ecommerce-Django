from django.views import View
from django.shortcuts import render,redirect
from store.models.customer import Customer
from django.contrib.auth.hashers import make_password
class Signup(View):
    def get(self,request):
        return render(request, 'signup.html')
    def post(self,request):
        return self.register(request);

    def register(self,request):
        postData = request.POST
        first_name = postData.get('fname');
        last_name = postData.get('lname');
        email = postData.get('email');
        password = postData.get('psw')
        phone = postData.get('phone')
        customer = Customer(
            first_name=first_name,
            last_name=last_name,
            email=email,
            password=password,
            phone=phone

        )
        customer.password = make_password(customer.password)
        customer.register();
        return redirect('homepage')




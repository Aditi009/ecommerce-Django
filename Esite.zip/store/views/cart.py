from django.views import View
from django.shortcuts import render, redirect
from store.models.product import Product
from django.contrib.auth.hashers import check_password


class Cart(View):
    def get(self, request):
        if request.session.get('cart'):
            id_list=list(request.session.get('cart').keys())
            products=Product.get_all_product_by_islist(id_list)
            print(products)
            return render(request,'cart.html',{'product':products})
        else:
            return render(request,'cartEmpty.html')





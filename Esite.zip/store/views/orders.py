from django.views import View
from django.shortcuts import render
from store.models.order import Order
from django.utils.decorators import method_decorator
from store.middlewares.auth import auth_middleware

class Orderview(View):
    @method_decorator(auth_middleware)
    def get(self,request):
        customer=request.session.get('customer_id')
        order=Order.get_order_by_customer(customer)
        return render(request,'order.html',{'orders':order});
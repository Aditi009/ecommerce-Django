from django.views import View
from django.shortcuts import render,redirect,HttpResponseRedirect
from store.models.customer import Customer
from django.contrib.auth.hashers import check_password


class Login(View):
    returnurl=None
    def get(self, request):
        Login.returnurl=request.GET.get('returnUrl')
        return render(request, 'login.html')

    def post(self, request):

        email = request.POST.get('email')
        password = request.POST.get('psw')
        customer = Customer.get_user_by_email(email)
        print(customer)
        error_msg = ""
        if customer:
            flag = check_password(password, customer.password)
            if flag:
                request.session['customer_id']=customer.id;
                request.session['customer_name'] = customer.first_name;

                if Login.returnurl:
                   return HttpResponseRedirect(Login.returnurl)
                else:
                   Login.returnurl=None
                   return redirect('homepage')
            else:
                error_msg = "Password incorrect"
        else:
            error_msg = "Email incorrect"
        return render(request, 'login.html', {'error': error_msg})
    
def logout(request):
    request.session.clear()
    return redirect('login')
